/* @flow */

export type AggregateObject = {
    id: number,
    value: string,
    counter: number,
    consoleArray: Array
}

