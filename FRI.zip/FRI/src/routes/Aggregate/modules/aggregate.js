// ------------------------------------
// Constants
// ------------------------------------
export const AGGREGATE_SOMEFUNC = 'AGGREGATE_SOMEFUNC'
export const AGGREGATE_SETPAGE = 'AGGREGATE_SETPAGE'

// ------------------------------------
// Actions
// ------------------------------------
export function somefunc () {
  return {
    type    : AGGREGATE_SOMEFUNC
  }
}
export function setpage () {
  return {
    type    : AGGREGATE_SETPAGE

  }
}


// ------------------------------------
// Action Handlers
// ------------------------------------
const ACTION_HANDLERS = {
  [AGGREGATE_SOMEFUNC] : (state, action) => state + action.payload,
  [AGGREGATE_SETPAGE] : function(state, action){
      state.pagination.currentPage=action.payload;
      return state;
    } 
}



// ------------------------------------
// Reducer
// ------------------------------------
const initialState = {counter: 10, 
  id:1234, 
  aggregateName:"some value", 
  consoleArray:[],
  records:[{
    "Dataset": "US Reg",	"Aggregate_ID": "1",	"Description": "Loans Secured by Real Estate",	"Type": "MDRM",	
    "MDRM": "1410",	"Dependency": "",	"Dep_Type": "Consolidated",	
    "Current_Quarter_Amount_Corporate": "$1,000",	"Prior_Quarter_Amount_Corporate": "$1,020",	"QoQ_Dollar": "$20",	"QoQ_Perc": "2%"},
    {
    "Dataset": "US Reg",	"Aggregate_ID": "2",	"Description": "Loans Secured by Real Estate",	"Type": "MDRM",	
    "MDRM": "1410",	"Dependency": "",	"Dep_Type": "Consolidated",	
    "Current_Quarter_Amount_Corporate": "$1,000",	"Prior_Quarter_Amount_Corporate": "$1,020",	"QoQ_Dollar": "$20",	"QoQ_Perc": "2%"},
    {
    "Dataset": "US Reg",	"Aggregate_ID": "3",	"Description": "Loans Secured by Real Estate",	"Type": "MDRM",	
    "MDRM": "1410",	"Dependency": "",	"Dep_Type": "Consolidated",	
    "Current_Quarter_Amount_Corporate": "$1,000",	"Prior_Quarter_Amount_Corporate": "$1,020",	"QoQ_Dollar": "$20",	"QoQ_Perc": "2%"},
    {
    "Dataset": "US Reg",	"Aggregate_ID": "4",	"Description": "Loans Secured by Real Estate",	"Type": "MDRM",	
    "MDRM": "1410",	"Dependency": "",	"Dep_Type": "Consolidated",	
    "Current_Quarter_Amount_Corporate": "$1,000",	"Prior_Quarter_Amount_Corporate": "$1,020",	"QoQ_Dollar": "$20",	"QoQ_Perc": "2%"},
    {
    "Dataset": "US Reg",	"Aggregate_ID": "5",	"Description": "Loans Secured by Real Estate",	"Type": "MDRM",	
    "MDRM": "1410",	"Dependency": "",	"Dep_Type": "Consolidated",	
    "Current_Quarter_Amount_Corporate": "$1,000",	"Prior_Quarter_Amount_Corporate": "$1,020",	"QoQ_Dollar": "$20",	"QoQ_Perc": "2%"},
    {
    "Dataset": "US Reg",	"Aggregate_ID": "6",	"Description": "Loans Secured by Real Estate",	"Type": "MDRM",	
    "MDRM": "1410",	"Dependency": "",	"Dep_Type": "Consolidated",	
    "Current_Quarter_Amount_Corporate": "$1,000",	"Prior_Quarter_Amount_Corporate": "$1,020",	"QoQ_Dollar": "$20",	"QoQ_Perc": "2%"}],
  pagination:{
    start : 10,
    end : 20,
    total: 50,
    pages: 5,
    currentPage: 2  
  }
}
export default function aggregateReducer (state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type]

  return handler ? handler(state, action) : state
}
