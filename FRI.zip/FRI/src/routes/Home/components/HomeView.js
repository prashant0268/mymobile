import React from 'react'
import './HomeView.scss'

export const HomeView = () => (
  <div>
    <h2>Dashboard</h2>
  </div>
)

export default HomeView
