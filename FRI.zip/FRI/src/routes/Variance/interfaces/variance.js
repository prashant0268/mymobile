/* @flow */

export type VarianceObject = {
    id: number,
    value: string,
    counter: number,
    consoleArray: Array
}

